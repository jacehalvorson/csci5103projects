# Project 1

## Group Members

- Jace Halvorson (halvo561)
- Ryan Johnsen (joh18447)

## Uthreads Library

### Compile and run

```sh
# Run main.cpp pi program
make pi
./pi 10000000 8

# Run tests for uthread_suspend/resume/init/create/exit/quantums/totalquantums
make testcase4
./testcase4

# Run tests for uthread_yield/join/self
make testcase5
./testcase5

# Run tests for max number of threads
make testcase6
./testcase6
```
